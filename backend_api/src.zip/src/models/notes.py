from sqlalchemy.dialects.postgresql import JSONB  # ✅ Import thêm
from sqlalchemy import Column, String, DateTime, ARRAY
from uuid import uuid4
from datetime import datetime
from src.db.database import Base

class Note(Base):
    __tablename__ = "notes"

    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    user_id = Column(String, nullable=False, index=True)
    title = Column(String)
    content = Column(String, nullable=False)
    content_json = Column(JSONB, nullable=True)  # ✅ Thêm trường mới
    tags = Column(ARRAY(String), default=[])
    sentiment = Column(String)  # kết quả phân tích cảm xúc
    emotions = Column(ARRAY(String), nullable=True, default=[])  # ✅ NEW: Add emotions column
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
