import openai
import os
from openai import OpenAI
import os
import json
from typing import List


async def analyze_emotions(text: str) -> List[str]:
    """
    Analyzes the emotions present in the given text using an AI model.
    Returns a list of detected emotions (e.g., ['joy', 'sadness']).
    """
    if not text.strip():
        return []  # Return empty list for empty text

    try:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable not set.")

        # Prompt the AI model for emotion analysis, asking for a JSON array
        result = await openai.ChatCompletion.acreate(
            model=OpenAI("gpt-4o", api_key=api_key),
            prompt=f"""Analyze the primary emotions expressed in the following diary entry/message.
            Return a JSON array of emotion labels. Use common emotions like 'joy', 'sadness', 'anger', 'fear', 'surprise', 'disgust', 'calm', 'excitement', 'neutral'.
            If no strong emotion is detected, return an empty array or ['neutral'].

            Example Output: ["joy", "calm"]
            Example Output: ["sadness"]
            Example Output: ["neutral"]

            Diary Entry: "{text}"
            """,
            response_format={"type": "json_object"},  # Request JSON object
            max_tokens=100,  # Allow enough tokens for a JSON array
        )

        # Parse the JSON response
        emotions_data = json.loads(result.text)

        if isinstance(emotions_data, dict) and "emotions" in emotions_data and isinstance(emotions_data["emotions"],
                                                                                          list):
            # If the AI wraps it in an "emotions" key
            emotions = [str(e).lower() for e in emotions_data["emotions"]]
        elif isinstance(emotions_data, list):
            # If the AI directly returns a list
            emotions = [str(e).lower() for e in emotions_data]
        else:
            print(f"AI returned unexpected emotion format: {result.text}. Defaulting to empty list.")
            return []

        # Filter out any non-string or empty values, and ensure uniqueness
        return sorted(list(set([e for e in emotions if isinstance(e, str) and e.strip()])))

    except json.JSONDecodeError as e:
        print(f"Error decoding AI emotion response JSON: {e}. Response: {result.text}")
        return []
    except Exception as e:
        print(f"Error during AI emotion analysis: {e}")
        return []  # Fallback to empty list on error
