import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()  # ⚠️ phải gọi trước os.getenv

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

async def analyze_sentiment(text: str) -> str:
    """
    Phân tích cảm xúc của nhật ký sử dụng API của OpenAI.
    Trả về: 'positive', 'negative', 'neutral', hoặc 'mixed'.
    """
    if not text.strip():
        return "neutral"

    try:
        response = await client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": f"""Analyze the sentiment of the following diary entry.
Respond with only one word: 'positive', 'negative', 'neutral', or 'mixed'.

Diary Entry: "{text}" """}
            ],
            max_tokens=10,
        )

        sentiment = response.choices[0].message.content.strip().lower()
        if sentiment in ["positive", "negative", "neutral", "mixed"]:
            return sentiment
        else:
            print(f"Unexpected response: {sentiment}")
            return "neutral"

    except Exception as e:
        print(f"Error during sentiment analysis: {e}")
        return "neutral"
