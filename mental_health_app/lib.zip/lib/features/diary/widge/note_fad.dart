import 'package:flutter/material.dart';

class NoteFab extends StatelessWidget {
  final VoidCallback onPressed;

  const NoteFab({Key? key, required this.onPressed}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: onPressed,
      backgroundColor: Colors.deepPurple, // Consistent with EmotionEntry's theme
      child: const Icon(Icons.add, color: Colors.white),
    );
  }
}
